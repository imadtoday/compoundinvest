import { LayoutDashboard, Users, Home, Megaphone, Settings, LogOut } from "lucide-react";
import { NavLink, useLocation } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarTrigger,
  useSidebar,
} from "@/components/ui/sidebar";


const items = [
  { title: "Dashboard", url: "/dashboard", icon: LayoutDashboard },
  { title: "Contacts", url: "/contacts", icon: Users },
  { title: "Campaigns", url: "/campaigns", icon: Megaphone },
  { title: "Users", url: "/users", icon: Users, requireSuperAdmin: true },
  { title: "Settings", url: "/settings", icon: Settings, requireSuperAdmin: true },
];

export function AppSidebar() {
  const { open, setOpen } = useSidebar();
  const location = useLocation();
  const currentPath = location.pathname;
  const { isSuperAdmin, signOut, profile } = useAuth();

  // Fetch company settings for logo and name
  const { data: settings } = useQuery({
    queryKey: ['company-settings'],
    queryFn: async () => {
      const { data } = await supabase
        .from('company_settings')
        .select('*')
        .limit(1)
        .single();
      return data;
    }
  });

  const isActive = (path: string) => currentPath === path;
  const getNavCls = ({ isActive }: { isActive: boolean }) =>
    isActive ? "bg-sidebar-accent text-sidebar-accent-foreground font-medium" : "text-sidebar-foreground hover:bg-sidebar-accent/50 hover:text-sidebar-accent-foreground";

  return (
    <Sidebar variant="sidebar" collapsible="icon">
      
      {/* Company Logo Section */}
      <div className="px-6 py-4 border-b border-sidebar-border">
        <div className="flex items-center justify-center">
          {settings?.logo_url ? (
            <div className="relative">
              <img 
                src={settings.logo_url} 
                alt="Company Logo" 
                className={`object-contain rounded ${open ? 'h-12 w-auto max-w-full' : 'h-10 w-10'}`}
                onError={(e) => {
                  console.log('Logo failed to load:', settings.logo_url);
                  e.currentTarget.style.display = 'none';
                }}
                onLoad={() => {
                  console.log('Logo loaded successfully:', settings.logo_url);
                }}
              />
              {/* Debug info - remove this later */}
              {process.env.NODE_ENV === 'development' && (
                <div className="absolute -bottom-8 left-0 text-xs text-white bg-black/50 p-1 rounded">
                  Logo loaded
                </div>
              )}
            </div>
          ) : (
            <div className={`bg-primary rounded flex items-center justify-center ${open ? 'h-12 w-12' : 'h-10 w-10'}`}>
              <span className={`text-primary-foreground font-bold ${open ? 'text-lg' : 'text-sm'}`}>CI</span>
            </div>
          )}
        </div>
      </div>

      <SidebarContent className="px-2">
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu className="space-y-2">
              {items
                .filter(item => !item.requireSuperAdmin || isSuperAdmin)
                .map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild>
                    <NavLink 
                      to={item.url} 
                      end 
                      className={({ isActive }) => 
                        `sidebar-nav-item flex items-center gap-3 px-3 py-3 text-sm font-medium transition-all duration-300 ${
                          isActive 
                            ? 'bg-sidebar-accent text-sidebar-accent-foreground shadow-lg active' 
                            : 'text-sidebar-foreground hover:bg-sidebar-accent/50 hover:text-sidebar-accent-foreground'
                        }`
                      }
                    >
                      <item.icon className="h-5 w-5 flex-shrink-0" />
                      {open && <span className="truncate">{item.title}</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {/* User Profile Section */}
        <div className="mt-auto p-4 border-t border-sidebar-border">
          {open && (
            <div className="space-y-2">
              <div className="text-sm">
                <p className="font-medium text-sidebar-foreground">
                  {profile?.first_name} {profile?.last_name}
                </p>
                <p className="text-sidebar-muted-foreground text-xs">
                  {profile?.role === 'super_admin' ? 'Super Admin' : 'Client'}
                </p>
              </div>
            </div>
          )}
        </div>
      </SidebarContent>
    </Sidebar>
  );
}
-- Add address field to contacts table
ALTER TABLE public.contacts 
ADD COLUMN address text;